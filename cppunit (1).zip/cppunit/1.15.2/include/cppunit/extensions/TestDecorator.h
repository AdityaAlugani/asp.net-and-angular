#ifndef CPPUNIT_EXTENSIONS_TESTDECORATOR_H
#define CPPUNIT_EXTENSIONS_TESTDECORATOR_H

#include <cppunit/Portability.h>
#include <cppunit/Test.h>

CPPUNIT_NS_BEGIN


class TestResult;


/*! \brief  Decorator for Tests.
 *
 * TestDecorator provides an alternate means to extend functionality
 * of a test class without subclassing the test.  Instead, one can
 * subclass the decorater and use it to wrap the test class.
 *
 * Assumes ownership of the test it decorates
 */ 
class CPPUNIT_API TestDecorator : public Test
{
public:
  TestDecorator( Test *test );
  ~TestDecorator() override;

  int countTestCases() const override;

  std::string getName() const override;

  void run( TestResult *result ) override;

  int getChildTestCount() const override;

protected:
  Test *doGetChildTestAt( int index ) const override;

  Test *m_test;

private:
  TestDecorator( const TestDecorator &);
  void operator =( const TestDecorator & );
};


CPPUNIT_NS_END

#endif

